export default {
    basePath: 'https://mypurecloud.github.io/purecloud-premium-app/premium-app-sample/'
}